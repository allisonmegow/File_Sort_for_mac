Welcome to the workflow that can sort your files!
The workflow included is specific to my needs. I download a lot of files and I wanted to auto sort specific file types into folders. you can change this to any file type (dont include the . before the file extension name) and any folder on your computer! 
HOW TO IMPLEMENT
1. Download the workflow. Adjust workflow to specific needs.
2. Move workflow to ~/Library/Workflows/Applications/Folder Actions
3. ctrl+click on desired folder in (yourname) location. SELECT Services > Folder Action Set up.
4. Click ok. Tick the boxes for the appropiate workflow for the appropriate folder.
5. You're done! This will start working as soon as new files are downloaded

Thank you for trying!
This workflow was created by Allison Megow with inspiration from various internet sources. contact allisonmegow@gmail.com for questions